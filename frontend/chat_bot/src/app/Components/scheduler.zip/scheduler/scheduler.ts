import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FullCalendarComponent, FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import { CalendarOptions, EventInput } from '@fullcalendar/core';

/* ---------------- TYPES ---------------- */
interface Slot {
  id: string;
  start: string;
  end: string;
  emergency: boolean;
}

interface Category {
  name: string;
  color: string;
  active: boolean;
}

interface MiniDay {
  day: number | '';
  isToday: boolean;
  isSelected: boolean;
}

@Component({
  selector: 'app-scheduler',
  standalone: true,
  imports: [CommonModule, FormsModule, FullCalendarModule],
  templateUrl: './scheduler.html',
  styleUrls: ['./scheduler.scss']
})
export class Scheduler implements AfterViewInit {


  repeatOption: 'none' | 'weekly'  = 'none';
  

  /* ---------------- BASIC ---------------- */
  title = '';
  description = '';
  selectedDuration = 15;

  durationOptions = [
    { label: '15 minutes', minutes: 15 },
    { label: '30 minutes', minutes: 30 },
    { label: '45 minutes', minutes: 45 },
    { label: '60 minutes', minutes: 60 }
  ];

  fullDayStart = '';
  fullDayEnd = '';
  maxBookingsPerDay?: number;

  categories: Category[] = [
    { name: 'General', color: '#3E7BFA', active: true },
    { name: 'Emergency', color: 'rgb(182,107,0)', active: true }
  ];

  /* ---------------- SAVE / UPDATE ---------------- */
  savedSchedules: {
    title: string;
    description: string;
    daySlots: any[];
  }[] = [];

  editingScheduleIndex: number | null = null;

  /* ---------------- CHANGE TRACKING ---------------- */
  private initialSnapshot: string | null = null;

  /* ---------------- DAY SLOTS ---------------- */
  daySlots: {
    label: string;
    unavailable: boolean;
    slots: Slot[];
  }[] = [];

  /* ---------------- CALENDAR ---------------- */
  @ViewChild('calendarRef') calendar!: FullCalendarComponent;

  calendarOptions: CalendarOptions = {
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin],
    initialView: 'timeGridWeek',
    headerToolbar: false,
    allDaySlot: false,
    slotMinTime: '00:00:00',
    slotMaxTime: '24:00:00',
    events: [],
    
    eventClick: (info:any) => this.openDrawerForEdit(info)
  };

  currentMonth = '';
  currentDayFullTitle = '';
  currentView = 'timeGridWeek';

  /* ---------------- MINI CALENDAR ---------------- */
  selectedMiniDate = new Date();
  miniMonth = '';
  miniCalendarDays: MiniDay[] = [];

  /* ---------------- UI ---------------- */
  drawerOpen = false;
  isNewEvent = true;
  toastMessage = '';
  toastVisible = false;

  private toastTimer: any;
  private autoGenTimer: any;

  /* ---------------- LIFECYCLE ---------------- */
  ngAfterViewInit() {
    this.initDaySlots();
    this.buildMiniCalendar();
    this.updateTitles();
  }

  /* ---------------- INIT ---------------- */
  initDaySlots() {
    const labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.daySlots = labels.map(l => ({
      label: l,
      unavailable: false,
      slots: []
    }));
  }

  /* ---------------- UTIL ---------------- */
  private parse(t: string) {
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  }

  private fmt(m: number) {
    const h = Math.floor(m / 60);
    const mm = m % 60;
    return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  }

  private makeSlot(s: string, e: string): Slot {
    return { id: crypto.randomUUID(), start: s, end: e, emergency: false };
  }

  private resolveEnd(): number {
    const e = this.parse(this.fullDayEnd);
    return e === 0 ? 1440 : e;
  }
 
  private canAutoGenerate(): boolean {
    return !!this.fullDayStart && !!this.fullDayEnd && this.selectedDuration > 0;
  }

  /* ---------------- AUTO GENERATE ---------------- */
  scheduleAutoGenerate() {
    clearTimeout(this.autoGenTimer);
    this.autoGenTimer = setTimeout(() => this.autoGenerateSlots(), 300);
  }

  autoGenerateSlots() {
    if (!this.canAutoGenerate()) return;

    const startM = this.parse(this.fullDayStart);
    const endM = this.resolveEnd();
    if (endM <= startM) return;

    this.daySlots.forEach(d => {
      if (d.unavailable) return;

      const slots: Slot[] = [];
      let cursor = startM;

      while (cursor + this.selectedDuration <= endM) {
        slots.push(this.makeSlot(
          this.fmt(cursor),
          this.fmt(cursor + this.selectedDuration)
        ));
        cursor += this.selectedDuration;
      }

      d.slots = slots;
    });

    this.syncCalendar();
  }

  /* ---------------- SLOT HELPERS ---------------- */
  getCombinedSlots(d: any): Slot[] {
    return d.slots;
  }

  isEmergency(_: any, s: Slot): boolean {
    return s.emergency;
  }

  onSlotChange(_di?: number, _slot?: Slot) {
    this.syncCalendar();
  }

  addSlot(di: number) {
    const d = this.daySlots[di];
    if (d.unavailable) return;

    let start = this.fullDayStart || '00:00';
    if (d.slots.length) {
      start = d.slots[d.slots.length - 1].end;
    }

    const sM = this.parse(start);
    const eM = sM + this.selectedDuration;

    d.slots.push(this.makeSlot(start, this.fmt(eM)));
    this.syncCalendar();
  }

  deleteSlot(di: number, s: Slot) {
    this.daySlots[di].slots = this.daySlots[di].slots.filter(x => x.id !== s.id);
    this.syncCalendar();
  }

  copySlotsToAllDays(srcIndex: number) {
    const src = this.daySlots[srcIndex];
    this.daySlots.forEach((d, i) => {
      if (i !== srcIndex && !d.unavailable) {
        d.slots = src.slots.map(s => ({ ...s, id: crypto.randomUUID() }));
      }
    });

    this.toast('Slots copied to all days');
    this.syncCalendar();
  }

  /* ---------------- REQUIRED BY HTML ---------------- */
  toggleCategory(_: Category) {}

  selectDurationChange(v: number) {
    this.selectedDuration = Number(v) || 15;
    this.scheduleAutoGenerate();
  }

  onFullDayTimeChange() {
    this.scheduleAutoGenerate();
  }

  onMaxBookingsChange(_: number) {}

  toggleDayAvailability(i: number) {
    this.daySlots[i].unavailable = !this.daySlots[i].unavailable;
    this.syncCalendar();
  }

  /* ---------------- CALENDAR ---------------- */
  syncCalendar() {
    if (!this.calendar) return;

    const api = this.calendar.getApi();
    api.removeAllEvents();

    // const base = api.view.currentStart;
    let base = api.view.currentStart;

    // if (!this.shouldRenderWeek(base)) return;
    
    const weeksToRender =
      this.repeatOption === 'weekly' ? 4 :
          1;

    for (let w = 0; w < weeksToRender; w++) {

      const weekBase = new Date(base);
      weekBase.setDate(base.getDate() + w * 7);

      // if (this.repeatOption === 'custom') {
      //   const diff = Math.floor(
      //     // (weekBase.getTime() - this.repeatStartDate.getTime()) /
      //     (weekBase.getTime() - new Date(this.repeatStartDate).getTime()) /
      //     (1000 * 60 * 60 * 24 * 7)
      //   );
      //   if (diff % this.repeatEveryWeeks !== 0) continue;
      // }

      // if (this.repeatEndDate && weekBase > this.repeatEndDate) continue;

      this.daySlots.forEach((d, di) => {

        if (d.unavailable) return;

      const date = new Date(weekBase);
      date.setDate(weekBase.getDate() + di);

      d.slots.forEach(s => {
        const [sh, sm] = s.start.split(':').map(Number);
        const [eh, em] = s.end.split(':').map(Number);

        const st = new Date(date);
        st.setHours(sh, sm, 0, 0);

        const en = new Date(date);
        en.setHours(eh, em, 0, 0);

        api.addEvent({
          title: s.emergency ? 'Emergency' : 'Slot',
          start: st,
          end: en,
          className: s.emergency ? 'fc-emergency' : 'fc-general'
        } as EventInput);
      });
    });
  }
  }

  /* ---------------- DRAWER ---------------- */
  openDrawerForAdd() {
    this.isNewEvent = true;
    this.editingScheduleIndex = null;
    this.drawerOpen = true;
    this.captureSnapshot();
  }

  /** ✅ ADDED — FIXES TEMPLATE ERROR */
  onAddButtonClicked() {
    this.openDrawerForAdd();
  }

  openDrawerForEdit(info?: any) {
    if (!this.savedSchedules.length) return;

    this.editingScheduleIndex = this.savedSchedules.length - 1;
    const data = this.savedSchedules[this.editingScheduleIndex];

    this.title = data.title;
    this.description = data.description;
    this.daySlots = JSON.parse(JSON.stringify(data.daySlots));

    this.isNewEvent = false;
    this.drawerOpen = true;
    this.captureSnapshot();
  }

  private captureSnapshot() {
    this.initialSnapshot = JSON.stringify({
      title: this.title,
      description: this.description,
      daySlots: this.daySlots
    });
  }

  private hasUnsavedChanges(): boolean {
    const current = JSON.stringify({
      title: this.title,
      description: this.description,
      daySlots: this.daySlots
    });
    return current !== this.initialSnapshot;
  }

  closeDrawer() {
    if (this.hasUnsavedChanges()) {
      const confirmClose = window.confirm(
        'You have unsaved changes. Are you sure you want to cancel?'
      );

      if (!confirmClose) return;

      if (this.initialSnapshot) {
        const original = JSON.parse(this.initialSnapshot);
        this.title = original.title;
        this.description = original.description;
        this.daySlots = JSON.parse(JSON.stringify(original.daySlots));
        this.syncCalendar();
      }
    }

    this.drawerOpen = false;
    this.initialSnapshot = null;
  }

  onSaveClicked() {
    this.savedSchedules.push({
      title: this.title,
      description: this.description,
      daySlots: JSON.parse(JSON.stringify(this.daySlots))
    });

    this.initialSnapshot = null;
    this.toast('Schedule saved');
    this.drawerOpen = false;
    this.syncCalendar();
  }

  onUpdateClicked() {
    if (this.editingScheduleIndex === null) return;

    this.savedSchedules[this.editingScheduleIndex] = {
      title: this.title,
      description: this.description,
      daySlots: JSON.parse(JSON.stringify(this.daySlots))
    };

    this.initialSnapshot = null;
    this.toast('Schedule updated');
    this.drawerOpen = false;
    this.syncCalendar();
  }

  deleteEvent() {
    this.toast('Deleted');
    this.closeDrawer();
  }

  /* ---------------- HEADER ---------------- */
  changeView(v: string) {
    this.currentView = v;
    this.calendar.getApi().changeView(v);
    this.updateTitles();
  }

  prev() {
    this.calendar.getApi().prev();
    this.updateTitles();
  }

  next() {
    this.calendar.getApi().next();
    this.updateTitles();
  }

  updateTitles() {
    const d = this.calendar.getApi().getDate();
    this.currentMonth = d.toLocaleString('default', { month: 'long', year: 'numeric' });
    this.currentDayFullTitle = d.toLocaleString('default', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  }

  /* ---------------- MINI CALENDAR ---------------- */
  buildMiniCalendar() {
    const y = this.selectedMiniDate.getFullYear();
    const m = this.selectedMiniDate.getMonth();

    this.miniMonth = this.selectedMiniDate.toLocaleString('default', {
      month: 'long',
      year: 'numeric'
    });

    const days = new Date(y, m + 1, 0).getDate();
    const start = new Date(y, m, 1).getDay();
    const today = new Date();

    this.miniCalendarDays = [];

    for (let i = 0; i < start; i++) {
      this.miniCalendarDays.push({ day: '', isToday: false, isSelected: false });
    }

    for (let d = 1; d <= days; d++) {
      this.miniCalendarDays.push({
        day: d,
        isToday:
          d === today.getDate() &&
          m === today.getMonth() &&
          y === today.getFullYear(),
        isSelected: false
      });
    }
  }

  miniDateClick(d: MiniDay) {
    if (!d.day) return;

    // clear previous selection
    this.miniCalendarDays.forEach(x => x.isSelected = false);
    d.isSelected = true;

    // build selected date
    const selected = new Date(
      this.selectedMiniDate.getFullYear(),
      this.selectedMiniDate.getMonth(),
      d.day
    );

    // navigate FullCalendar
    this.calendar.getApi().gotoDate(selected);

    // update titles
    this.updateTitles();
  }

  prevMini() {
    this.selectedMiniDate.setMonth(this.selectedMiniDate.getMonth() - 1);
    this.buildMiniCalendar();
  }

  nextMini() {
    this.selectedMiniDate.setMonth(this.selectedMiniDate.getMonth() + 1);
    this.buildMiniCalendar();
  }

  /* ---------------- TOAST ---------------- */
  private toast(msg: string) {
    this.toastMessage = msg;
    this.toastVisible = true;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => (this.toastVisible = false), 1800);
  }

  onRepeatChange() {
    
    this.syncCalendar();
  }



}
