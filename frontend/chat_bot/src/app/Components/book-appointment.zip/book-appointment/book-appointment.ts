import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface BookingInfo {
  fullName: string;
  phone: string;
  email?: string;
  message?: string;
}

interface Slot {
  time: string;
  status: 'open' | 'booked';
  bookingInfo?: BookingInfo;
}

interface DaySlots {
  date: Date;
  slots: Slot[];
}

interface MiniDate {
  day: number | null;
  date?: Date;
  isToday?: boolean;
  isSelected?: boolean;
}

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './book-appointment.html',
  styleUrls: ['./book-appointment.scss']
})
export class BookAppointment implements OnInit {

  currentWeekStart!: Date;
  weekDays: DaySlots[] = [];

  miniDays: MiniDate[] = [];
  miniMonthYear = '';

  showModal = false;
  selectedDay!: Date;
  selectedSlot!: Slot;

  submitted = false;

  patient = {
    fullName: '',
    countryCode: '+91',
    phone: '',
    email: '',
    message: ''
  };

  // ✅ DUMMY DATA WITH BOOKING INFO
  scheduledSlots: Record<string, Slot[]> = {
    '2026-01-06': [
      { time: '9:00am - 9:30am', status: 'open' },
      {
        time: '10:30am',
        status: 'booked',
        bookingInfo: { fullName: 'Rahul Sharma', phone: '9876543210' }
      },
      { time: '12:00pm', status: 'open' },
      {
        time: '3:00pm',
        status: 'booked',
        bookingInfo: { fullName: 'Anita Verma', phone: '9123456780' }
      }
    ],
    '2026-01-07': [
      { time: '9:00am', status: 'open' },
      {
        time: '10:00am',
        status: 'booked',
        bookingInfo: { fullName: 'Karthik R', phone: '9988776655' }
      },
      { time: '4:30pm', status: 'open' }
    ],
    '2026-01-08': [
      { time: '9:00am', status: 'open' },
      {
        time: '12:00pm',
        status: 'booked',
        bookingInfo: { fullName: 'Sneha Patel', phone: '9000012345' }
      },
      { time: '1:30pm', status: 'open' }
    ],
    '2026-01-09': [
      {
        time: '9:00am',
        status: 'booked',
        bookingInfo: { fullName: 'Amit Kumar', phone: '9555444333' }
      },
      { time: '10:30am', status: 'open' }
    ],
    '2026-01-12': [
      { time: '9:00am - 9:30am', status: 'open' },
      {
        time: '10:30am',
        status: 'booked',
        bookingInfo: { fullName: 'Mohit', phone: '9876543210' }
      },
      { time: '12:00pm', status: 'open' },
      {
        time: '3:00pm',
        status: 'booked',
        bookingInfo: { fullName: 'Vijay', phone: '9123456780' }
      }
    ],
    '2026-01-13': [
      { time: '9:00am', status: 'open' },
      {
        time: '10:00am',
        status: 'booked',
        bookingInfo: { fullName: 'Spoorthi', phone: '9988776655' }
      },
      { time: '4:30pm', status: 'open' }
    ],
    '2026-01-14': [
      { time: '9:00am', status: 'open' },
      {
        time: '12:00pm',
        status: 'booked',
        bookingInfo: { fullName: 'Akhila', phone: '9000012345' }
      },
      { time: '1:30pm', status: 'open' }
    ],
    '2026-01-15': [
      {
        time: '9:00am',
        status: 'booked',
        bookingInfo: { fullName: 'Pavan', phone: '9555444333' }
      },
      { time: '10:30am', status: 'open' }
    ]
  };

  ngOnInit() {
    const today = new Date();
    this.setWeekStart(today);
    this.buildMiniCalendar(today);
  }

  resetForm() {
    this.submitted = false;
    this.patient = {
      fullName: '',
      countryCode: '+91',
      phone: '',
      email: '',
      message: ''
    };
  }

  setWeekStart(date: Date) {
    const d = new Date(date);
    d.setDate(d.getDate() - d.getDay());
    this.currentWeekStart = d;
    this.buildWeek();
  }

  buildWeek() {
    this.weekDays = [];

    for (let i = 0; i < 7; i++) {
      const d = new Date(this.currentWeekStart);
      d.setDate(d.getDate() + i);
      const key = this.formatDate(d);

      this.weekDays.push({
        date: d,
        slots: this.scheduledSlots[key]
          ? this.scheduledSlots[key].map(s => ({ ...s }))
          : []
      });
    }
  }

  prevWeek() {
    const d = new Date(this.currentWeekStart);
    d.setDate(d.getDate() - 7);
    this.setWeekStart(d);
    this.buildMiniCalendar(d);
  }

  nextWeek() {
    const d = new Date(this.currentWeekStart);
    d.setDate(d.getDate() + 7);
    this.setWeekStart(d);
    this.buildMiniCalendar(d);
  }

  buildMiniCalendar(base: Date) {
    const year = base.getFullYear();
    const month = base.getMonth();
    const today = new Date();

    this.miniMonthYear = base.toLocaleString('default', {
      month: 'long',
      year: 'numeric'
    });

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    this.miniDays = [];

    for (let i = 0; i < firstDay; i++) {
      this.miniDays.push({ day: null });
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      this.miniDays.push({
        day: d,
        date,
        isToday: date.toDateString() === today.toDateString(),
        isSelected: date.toDateString() === base.toDateString()
      });
    }
  }

  onMiniDateClick(day: MiniDate) {
    if (!day.date) return;
    this.setWeekStart(day.date);
    this.buildMiniCalendar(day.date);
  }

  formatDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  openBooking(slot: Slot, day: Date) {
    if (slot.status === 'booked') return;

    this.resetForm();
    this.selectedSlot = slot;
    this.selectedDay = day;
    this.showModal = true;

    // ✅ stop background scroll
    document.body.style.overflow = 'hidden';
  }

  isValidEmail(email: string): boolean {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
  }

  confirmBooking() {
    this.submitted = true;

    // ✅ VALIDATIONS
    if (!this.patient.fullName) return;
    if (!this.patient.phone || this.patient.phone.length < 10) return;
    if (!this.patient.email || !this.isValidEmail(this.patient.email)) return;

    // ✅ BOOK
    this.selectedSlot.status = 'booked';
    this.selectedSlot.bookingInfo = {
      fullName: this.patient.fullName,
      phone: `${this.patient.countryCode} ${this.patient.phone}`,
      email: this.patient.email,
      message: this.patient.message
    };

    this.closeModal();
  }

  closeModal() {
    this.showModal = false;
    this.resetForm();

    // ✅ enable background scroll
    document.body.style.overflow = 'auto';
  }

  allowOnlyNumbers(event: KeyboardEvent) {
    const code = event.key.charCodeAt(0);
    if (code < 48 || code > 57) {
      event.preventDefault();
    }
  }
}
