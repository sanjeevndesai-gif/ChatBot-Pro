import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  ElementRef,
  AfterViewInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import QRCode from 'qrcode';
import { downloadQrFromCanvas } from '../../utils/qr-utils';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.scss']
})
export class Profile implements AfterViewInit {

  @ViewChild('qrCanvas') qrCanvas!: ElementRef<HTMLCanvasElement>;

  // ✅ Dummy user data
  user = {
    id: 1234,
    fullName: 'John Doe',
    title: 'UX Designer',
    location: 'Vatican City',
    joined: 'Joined April 2021',
    status: 'Active',
    role: 'Developer',
    country: 'USA',
    languages: 'English',
    contact: '(123) 456-7890',
    skype: 'john.doe',
    email: 'john.doe@example.com',
    address: 'Btm layout 2nd stage',
    qrValue: 'https://myapp.com/profile/1234'
  };

  // ✅ QR Value derived from user
  get profileUrl(): string {
    return this.user.qrValue;
  }

  ngAfterViewInit(): void {
    this.generateQR();
  }

  // ✅ Generate QR on canvas
  generateQR(): void {
    if (!this.qrCanvas?.nativeElement) return;

    QRCode.toCanvas(
      this.qrCanvas.nativeElement,
      this.profileUrl,
      {
        width: 150,
        margin: 2,
        errorCorrectionLevel: 'M',
        color: {
          dark: '#000000',
          light: '#ffffff'
        }
      },
      (error?: Error | null) => {
        if (error) {
          console.error('QR generation failed:', error);
        }
      }
    );
  }

  // ✅ Download QR using shared utility
  downloadQR(): void {
    downloadQrFromCanvas(this.qrCanvas.nativeElement, `profile-${this.user.id}-qr.png`);
  }
}
