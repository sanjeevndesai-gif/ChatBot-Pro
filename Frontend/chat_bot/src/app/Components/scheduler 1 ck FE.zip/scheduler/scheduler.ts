import { Component, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FullCalendarComponent, FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import { CalendarOptions, EventInput } from '@fullcalendar/core';
import { SchedulerService } from '../../services/scheduler.service';

/* ---------------- TYPES ---------------- */
interface Slot {
  id: string;
  start: string;
  end: string;
  emergency: boolean;
}

interface Category {
  name: string;
  color: string;
  active: boolean;
}

interface MiniDay {
  day: number | '';
  isToday: boolean;
  isSelected: boolean;
}

@Component({
  selector: 'app-scheduler',
  standalone: true,
  imports: [CommonModule, FormsModule, FullCalendarModule],
  templateUrl: './scheduler.html',
  styleUrls: ['./scheduler.scss']
})
export class Scheduler implements AfterViewInit, OnInit {

  constructor(private schedulerService: SchedulerService) { }

  /* ---------------- BACKEND STATE ---------------- */
  userId!: string;
  schedulers: any[] = [];

  userDropdownOpen = false;
  userSearchText = '';

  // repeatOption: 'none' | 'weekly' = 'none';
  repeatOption: 'none' | 'weekly' | 'custom' = 'none';

  /* ---------------- MULTI USER + CUSTOM REPEAT ---------------- */

  users = [
    { id: '1', name: 'Dr. John' },
    { id: '2', name: 'Dr. Priya' },
    { id: '3', name: 'Dr. Smith' }
  ];

  selectedUsers: any[] = [];

  repeatWeeks: number = 1;
  customFromDate: string = '';
  customToDate: string = '';


  /* ---------------- BASIC ---------------- */
  title = '';
  description = '';
  selectedDuration = 15;

  durationOptions = [
    { label: '15 minutes', minutes: 15 },
    { label: '30 minutes', minutes: 30 },
    { label: '45 minutes', minutes: 45 },
    { label: '60 minutes', minutes: 60 }
  ];

  fullDayStart = '';
  fullDayEnd = '';
  maxBookingsPerDay?: number;

  categories: Category[] = [
    { name: 'General', color: '#3E7BFA', active: true },
    { name: 'Emergency', color: 'rgb(182,107,0)', active: true }
  ];

  /* ---------------- SAVE / UPDATE ---------------- */
  savedSchedules: {
    title: string;
    description: string;
    daySlots: any[];
  }[] = [];

  editingScheduleIndex: number | null = null;
  private initialSnapshot: string | null = null;

  /* ---------------- DAY SLOTS ---------------- */
  daySlots: {
    label: string;
    unavailable: boolean;
    slots: Slot[];
  }[] = [];

  /* ---------------- CALENDAR ---------------- */
  @ViewChild('calendarRef') calendar!: FullCalendarComponent;

  // calendarOptions: CalendarOptions = {
  //   plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin],
  //   initialView: 'timeGridWeek',
  //   headerToolbar: false,
  //   allDaySlot: false,
  //   slotMinTime: '00:00:00',
  //   slotMaxTime: '24:00:00',
  //   events: [],
  //   eventClick: (info: any) => this.openDrawerForEdit(info)
  // };

  calendarOptions: CalendarOptions = {
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin, listPlugin],
    initialView: 'timeGridWeek',
    headerToolbar: false,
    allDaySlot: false,
    slotMinTime: '00:00:00',
    slotMaxTime: '24:00:00',

    slotDuration: '00:15:00',
    slotLabelInterval: '01:00',
    eventMinHeight: 24,
    expandRows: true,

    // ✅ IMPORTANT — 24 HOUR FORMAT
    eventTimeFormat: {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    },

    // ✅ IMPORTANT — remove default time text
    displayEventTime: false,

    events: [],
    eventClick: (info: any) => this.openDrawerForEdit(info),

    eventDidMount: (info) => {
      const start = new Date(info.event.start!);
      const end = new Date(info.event.end!);
      const duration = (end.getTime() - start.getTime()) / 60000;

      const el = info.el as HTMLElement;

      if (duration <= 15) {
        el.style.fontSize = '10px';
      } else if (duration <= 30) {
        el.style.fontSize = '11px';
      } else {
        el.style.fontSize = '12px';
      }
    }
  };

  currentMonth = '';
  currentDayFullTitle = '';
  currentView = 'timeGridWeek';

  /* ---------------- MINI CALENDAR ---------------- */
  selectedMiniDate = new Date();
  miniMonth = '';
  miniCalendarDays: MiniDay[] = [];

  /* ---------------- UI ---------------- */
  drawerOpen = false;
  isNewEvent = true;
  toastMessage = '';
  toastVisible = false;

  private toastTimer: any;
  private autoGenTimer: any;

  /* ---------------- LIFECYCLE ---------------- */
  ngOnInit() {
    const authUser = localStorage.getItem('auth_user');
    if (!authUser) return;

    this.userId = JSON.parse(authUser).userId;
    this.loadFromCache();
    this.loadFromBackend();
  }

  ngAfterViewInit() {
    this.initDaySlots();
    this.buildMiniCalendar();
    this.updateTitles();
  }

  /* ---------------- BACKEND LOADERS ---------------- */
  loadFromCache() {
    const cached = localStorage.getItem('schedule_data');
    if (cached) this.schedulers = JSON.parse(cached);
  }

  loadFromBackend() {
    this.schedulerService.getSchedulersByUser(this.userId)
      .subscribe(res => {
        this.schedulers = res;
        localStorage.setItem('schedule_data', JSON.stringify(res));
      });
  }

  /* ---------------- INIT ---------------- */
  initDaySlots() {
    const labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.daySlots = labels.map(l => ({
      label: l,
      unavailable: false,
      slots: []
    }));
  }

  /* ---------------- UTIL ---------------- */
  private parse(t: string) {
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  }

  private fmt(m: number) {
    const h = Math.floor(m / 60);
    const mm = m % 60;
    return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  }

  private makeSlot(s: string, e: string): Slot {
    return { id: crypto.randomUUID(), start: s, end: e, emergency: false };
  }

  private resolveEnd(): number {
    const e = this.parse(this.fullDayEnd);
    return e === 0 ? 1440 : e;
  }

  private canAutoGenerate(): boolean {
    return !!this.fullDayStart && !!this.fullDayEnd && this.selectedDuration > 0;
  }

  /* ---------------- AUTO GENERATE ---------------- */
  scheduleAutoGenerate() {
    clearTimeout(this.autoGenTimer);
    this.autoGenTimer = setTimeout(() => this.autoGenerateSlots(), 300);
  }

  autoGenerateSlots() {
    if (!this.canAutoGenerate()) return;

    const startM = this.parse(this.fullDayStart);
    const endM = this.resolveEnd();
    if (endM <= startM) return;

    this.daySlots.forEach(d => {
      if (d.unavailable) return;

      const slots: Slot[] = [];
      let cursor = startM;

      while (cursor + this.selectedDuration <= endM) {
        slots.push(this.makeSlot(
          this.fmt(cursor),
          this.fmt(cursor + this.selectedDuration)
        ));
        cursor += this.selectedDuration;
      }

      d.slots = slots;
    });

    this.syncCalendar();
  }

  /* ---------------- SLOT HELPERS ---------------- */
  getCombinedSlots(d: any): Slot[] {
    return d.slots;
  }

  isEmergency(_: any, s: Slot): boolean {
    return s.emergency;
  }

  onSlotChange(_di?: number, _slot?: Slot) {
    this.syncCalendar();
  }

  addSlot(di: number) {
    const d = this.daySlots[di];
    if (d.unavailable) return;

    let start = this.fullDayStart || '00:00';
    if (d.slots.length) start = d.slots[d.slots.length - 1].end;

    const sM = this.parse(start);
    d.slots.push(this.makeSlot(start, this.fmt(sM + this.selectedDuration)));
    this.syncCalendar();
  }

  deleteSlot(di: number, s: Slot) {
    this.daySlots[di].slots = this.daySlots[di].slots.filter(x => x.id !== s.id);
    this.syncCalendar();
  }

  copySlotsToAllDays(srcIndex: number) {
    const src = this.daySlots[srcIndex];
    this.daySlots.forEach((d, i) => {
      if (i !== srcIndex && !d.unavailable) {
        d.slots = src.slots.map(s => ({ ...s, id: crypto.randomUUID() }));
      }
    });
    this.toast('Slots copied to all days');
    this.syncCalendar();
  }

  /* ---------------- TEMPLATE REQUIRED ---------------- */
  toggleCategory(_: Category) { }

  selectDurationChange(v: number) {
    this.selectedDuration = Number(v) || 15;
    this.scheduleAutoGenerate();
  }

  onFullDayTimeChange() {
    this.scheduleAutoGenerate();
  }

  onMaxBookingsChange(_: number) { }

  toggleDayAvailability(i: number) {
    this.daySlots[i].unavailable = !this.daySlots[i].unavailable;
    this.syncCalendar();
  }

  /* ---------------- SAVE ---------------- */
  onSaveClicked() {
    this.saveSchedulerToBackend();
  }

  onUpdateClicked() {
    this.saveSchedulerToBackend();
  }

  // saveSchedulerToBackend() {
  //   const selectedDate =
  //     this.calendar.getApi().getDate().toISOString().split('T')[0];

  //   const payload = {
  //     userId: this.userId,
  //     slotTitle: this.title,
  //     scheduleDate: selectedDate,
  //     weeklyRepeat: this.repeatOption === 'weekly',
  //     repeatDays: this.daySlots
  //       .filter(d => !d.unavailable)
  //       .map(d => d.label.substring(0, 3).toUpperCase()),
  //     slots: this.daySlots.flatMap(d =>
  //       d.slots.map(s => ({
  //         startTime: s.start,
  //         endTime: s.end,
  //         emergency: s.emergency
  //       }))
  //     )
  //   };

  //   this.schedulerService.saveScheduler(payload)
  //     .subscribe(res => {
  //       this.mergeScheduler(res);
  //       this.toast('Schedule saved');
  //       this.drawerOpen = false;
  //       this.syncCalendar();
  //     });
  // }
  saveSchedulerToBackend() {

    if (!this.title) {
      alert("Please enter title");
      return;
    }

    if (this.selectedUsers.length === 0) {
      alert("Please select at least one user");
      return;
    }

    const baseDate =
      this.calendar.getApi().getDate().toISOString().split('T')[0];

    let datesToGenerate: Date[] = [];

    // DO NOT REPEAT
    if (this.repeatOption === 'none') {
      datesToGenerate.push(new Date(baseDate));
    }

    // WEEKLY
    if (this.repeatOption === 'weekly') {

      if (!this.repeatWeeks || this.repeatWeeks < 1) {
        alert("Enter valid number of weeks");
        return;
      }

      for (let i = 0; i < this.repeatWeeks; i++) {
        let d = new Date(baseDate);
        d.setDate(d.getDate() + (i * 7));
        datesToGenerate.push(d);
      }
    }

    // CUSTOM RANGE
    if (this.repeatOption === 'custom') {

      if (!this.customFromDate || !this.customToDate) {
        alert("Select custom date range");
        return;
      }

      let start = new Date(this.customFromDate);
      let end = new Date(this.customToDate);

      if (start > end) {
        alert("From date cannot be greater than To date");
        return;
      }

      while (start <= end) {
        datesToGenerate.push(new Date(start));
        start.setDate(start.getDate() + 1);
      }
    }

    // SAVE FOR EACH USER + EACH DATE
    datesToGenerate.forEach(date => {

      this.selectedUsers.forEach(user => {

        const payload = {
          userId: user.id,
          slotTitle: this.title,
          scheduleDate: date.toISOString().split('T')[0],
          weeklyRepeat: this.repeatOption === 'weekly',
          repeatDays: this.daySlots
            .filter(d => !d.unavailable)
            .map(d => d.label.substring(0, 3).toUpperCase()),
          slots: this.daySlots.flatMap(d =>
            d.slots.map(s => ({
              startTime: s.start,
              endTime: s.end,
              emergency: s.emergency
            }))
          )
        };

        // Backend save
        this.schedulerService.saveScheduler(payload)
          .subscribe(res => {
            this.mergeScheduler(res);
          });

        // Local storage save
        let localData =
          JSON.parse(localStorage.getItem('schedule_data') || '[]');

        localData.push(payload);
        localStorage.setItem('schedule_data', JSON.stringify(localData));
      });
    });

    this.toast('Schedule saved successfully');
    this.drawerOpen = false;
    this.syncCalendar();
  }

  mergeScheduler(updated: any) {
    const idx = this.schedulers.findIndex(
      s => s.schedulerId === updated.schedulerId
    );
    if (idx > -1) this.schedulers[idx] = updated;
    else this.schedulers.push(updated);

    localStorage.setItem('schedule_data', JSON.stringify(this.schedulers));
  }

  /* ---------------- CALENDAR ---------------- */
  syncCalendar() {
    if (!this.calendar) return;

    const api = this.calendar.getApi();
    api.removeAllEvents();
    
    // const selectedDate = api.getDate();

    // if (!this.calendar) return;

  
    const viewStart = api.view.currentStart;   // week start
    const viewEnd = api.view.currentEnd;       // week end

    let datesToRender: Date[] = [];

    /* ---------------- DO NOT REPEAT ---------------- */
    if (this.repeatOption === 'none') {

      let current = new Date(viewStart);

      while (current < viewEnd) {
        datesToRender.push(new Date(current));
        current.setDate(current.getDate() + 1);
      }
    }

    /* ================= WEEKLY ================= */
    if (this.repeatOption === 'weekly') {

      for (let w = 0; w < this.repeatWeeks; w++) {

        let current = new Date(viewStart);
        current.setDate(current.getDate() + (w * 7));

        for (let i = 0; i < 7; i++) {
          datesToRender.push(new Date(current));
          current.setDate(current.getDate() + 1);
        }
      }
    }

    /* ---------------- CUSTOM RANGE ---------------- */
    if (this.repeatOption === 'custom') {

      if (!this.customFromDate || !this.customToDate) return;

      let start = new Date(this.customFromDate);
      let end = new Date(this.customToDate);

      while (start <= end) {
        datesToRender.push(new Date(start));
        start.setDate(start.getDate() + 1);
      }
    }

    /* ---------------- GENERATE EVENTS ---------------- */

    datesToRender.forEach(date => {

      const weekdayIndex = date.getDay(); // 0-6

      const dayConfig = this.daySlots[weekdayIndex];

      if (!dayConfig || dayConfig.unavailable) return;

      dayConfig.slots.forEach(slot => {

        const [sh, sm] = slot.start.split(':').map(Number);
        const [eh, em] = slot.end.split(':').map(Number);

        const startTime = new Date(date);
        startTime.setHours(sh, sm, 0, 0);

        const endTime = new Date(date);
        endTime.setHours(eh, em, 0, 0);

        api.addEvent({
          // title: slot.emergency ? 'Emergency' : 'Slot',
          title: `${slot.start} - ${slot.end} ${slot.emergency ? 'E' : 'G'}`,
          start: startTime,
          end: endTime,
          className: slot.emergency ? 'fc-emergency' : 'fc-general'
        });
      });

    });

  }


  /* ---------------- DRAWER ---------------- */
  openDrawerForAdd() {
    this.isNewEvent = true;
    this.drawerOpen = true;
    this.captureSnapshot();
  }

  onAddButtonClicked() {
    this.calendar.getApi().changeView('timeGridWeek');
    this.currentView = 'timeGridWeek';
    this.updateTitles();
    this.openDrawerForAdd();
  }

  openDrawerForEdit(_: any) {
    this.isNewEvent = false;
    this.drawerOpen = true;
    this.captureSnapshot();
  }

  private captureSnapshot() {
    this.initialSnapshot = JSON.stringify({
      title: this.title,
      description: this.description,
      daySlots: this.daySlots
    });
  }

  closeDrawer() {
    this.drawerOpen = false;
    this.initialSnapshot = null;
  }

  deleteEvent() {
    if (!confirm('Delete this schedule?')) return;
    this.toast('Deleted');
    this.closeDrawer();
  }

  /* ---------------- HEADER ---------------- */
  changeView(v: string) {
    this.currentView = v;
    this.calendar.getApi().changeView(v);
    this.updateTitles();
  }

  prev() {
    this.calendar.getApi().prev();
    this.updateTitles();
  }

  next() {
    this.calendar.getApi().next();
    this.updateTitles();
  }

  updateTitles() {
    const d = this.calendar.getApi().getDate();
    this.currentMonth = d.toLocaleString('default', { month: 'long', year: 'numeric' });
    this.currentDayFullTitle = d.toLocaleString('default', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  }

  // onUserSelectionChange(event: any, user: any) {
  //   if (event.target.checked) {
  //     this.selectedUsers.push(user);
  //   } else {
  //     this.selectedUsers =
  //       this.selectedUsers.filter(u => u.id !== user.id);
  //   }
  // }


  /* ---------------- MINI CALENDAR ---------------- */
  buildMiniCalendar() {
    const y = this.selectedMiniDate.getFullYear();
    const m = this.selectedMiniDate.getMonth();

    this.miniMonth = this.selectedMiniDate.toLocaleString('default', {
      month: 'long',
      year: 'numeric'
    });

    const days = new Date(y, m + 1, 0).getDate();
    const start = new Date(y, m, 1).getDay();
    const today = new Date();

    this.miniCalendarDays = [];

    for (let i = 0; i < start; i++) {
      this.miniCalendarDays.push({ day: '', isToday: false, isSelected: false });
    }

    for (let d = 1; d <= days; d++) {
      this.miniCalendarDays.push({
        day: d,
        isToday:
          d === today.getDate() &&
          m === today.getMonth() &&
          y === today.getFullYear(),
        isSelected: false
      });
    }
  }

  prevMini() {
    this.selectedMiniDate.setMonth(this.selectedMiniDate.getMonth() - 1);
    this.buildMiniCalendar();
  }

  nextMini() {
    this.selectedMiniDate.setMonth(this.selectedMiniDate.getMonth() + 1);
    this.buildMiniCalendar();
  }

  miniDateClick(d: MiniDay) {
    if (!d.day) return;

    this.miniCalendarDays.forEach(x => x.isSelected = false);
    d.isSelected = true;

    const selected = new Date(
      this.selectedMiniDate.getFullYear(),
      this.selectedMiniDate.getMonth(),
      d.day
    );

    this.calendar.getApi().gotoDate(selected);
    this.updateTitles();
  }

  /* ---------------- TOAST ---------------- */
  private toast(msg: string) {
    this.toastMessage = msg;
    this.toastVisible = true;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => (this.toastVisible = false), 1800);
  }

  onRepeatChange() {

    if (this.repeatOption === 'custom') {
      this.calendar.getApi().changeView('dayGridMonth');
    }

    if (this.repeatOption === 'weekly') {
      this.calendar.getApi().changeView('timeGridWeek');
    }

    this.syncCalendar();
    this.calendar.getApi().changeView('timeGridWeek');
    this.currentView = 'timeGridWeek';
    this.updateTitles();

  }

  toggleUserDropdown() {
    this.userDropdownOpen = !this.userDropdownOpen;
  }

  filteredUsers() {
    return this.users.filter(u =>
      u.name.toLowerCase().includes(this.userSearchText.toLowerCase())
    );
  }

  isUserSelected(user: any): boolean {
    return this.selectedUsers.some(u => u.id === user.id);
  }

  onUserCheckboxChange(event: any, user: any) {
    if (event.target.checked) {
      this.selectedUsers.push(user);
    } else {
      this.selectedUsers =
        this.selectedUsers.filter(u => u.id !== user.id);
    }
  }

  isAllSelected(): boolean {
    const filtered = this.filteredUsers();

    if (filtered.length === 0) return false;

    return filtered.every(user =>
      this.selectedUsers.some(u => u.id === user.id)
    );
  }

  toggleSelectAll(event: any) {
    const filtered = this.filteredUsers();

    if (event.target.checked) {
      filtered.forEach(user => {
        if (!this.isUserSelected(user)) {
          this.selectedUsers.push(user);
        }
      });
    } else {
      this.selectedUsers = this.selectedUsers.filter(
        u => !filtered.some(f => f.id === u.id)
      );
    }
  }

}
