import { Component } from '@angular/core';
import { Horizontalmenu } from '../../Components/horizontalmenu/horizontalmenu';

@Component({
  selector: 'app-layout',
  imports: [Horizontalmenu],
  templateUrl: './layout.html',
  styleUrl: './layout.scss'
})
export class Layout {

}
